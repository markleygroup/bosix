import sys
sys.path.insert(0,"/home/ansible/bosix/ansible_command_payload_J4n2mJ/ansible_command_payload.zip")
