import sys
sys.path.insert(0,"/home/ansible/bosix/ansible_command_payload_gbCH8y/ansible_command_payload.zip")
