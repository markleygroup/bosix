import sys
sys.path.insert(0,"/home/ansible/bosix/ansible_command_payload__YvpwG/ansible_command_payload.zip")
